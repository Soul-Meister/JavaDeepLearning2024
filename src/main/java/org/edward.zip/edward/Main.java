package org.edward;

public class Main {
    public static void main(String[] args) {
        FlappyBirdEnvironment environment = new FlappyBirdEnvironment();
    }
}